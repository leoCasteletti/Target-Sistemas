using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

class Program
{
    static void Main()
    {
        // Define a codificação do console para UTF-8
        Console.OutputEncoding = Encoding.UTF8;

        // Lendo o JSON do arquivo
        string jsonFilePath = "dados.json";
        string jsonData = File.ReadAllText(jsonFilePath);
        
        // Desserializar JSON em uma lista de objetos
        List<DiaFaturamento> dados = JsonConvert.DeserializeObject<List<DiaFaturamento>>(jsonData);

        // Filtrando dias com faturamento maior que zero
        var faturamentos = dados.Where(d => d.Valor > 0).Select(d => d.Valor).ToList();

        // Verificando se existem valores válidos
        if (faturamentos.Count == 0)
        {
            Console.WriteLine("Não há dados de faturamento disponíveis.");
            return;
        }

        // Cálculo do menor e maior faturamento
        double menorFaturamento = faturamentos.Min();
        double maiorFaturamento = faturamentos.Max();

        // Cálculo da média dos faturamentos válidos
        double mediaMensal = faturamentos.Average();

        // Contando os dias que tiveram faturamento acima da média
        int diasAcimaDaMedia = faturamentos.Count(f => f > mediaMensal);

        // Exibindo os resultados
        Console.WriteLine($"Menor faturamento diário: R$ {menorFaturamento:F2}");
        Console.WriteLine($"Maior faturamento diário: R$ {maiorFaturamento:F2}");
        Console.WriteLine($"Dias com faturamento acima da média: {diasAcimaDaMedia} dias");
    }
}

// Classe para mapear os dados do JSON
class DiaFaturamento
{
    public int Dia { get; set; }
    public double Valor { get; set; }
}
