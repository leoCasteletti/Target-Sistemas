using System;
using System.Text;

class Program
{
    static void Main()
    {
        // Define a codificação do console para UTF-8
        Console.OutputEncoding = Encoding.UTF8;

        Console.Write("Digite um número para verificar se pertence à sequência de Fibonacci: ");
        int numero = int.Parse(Console.ReadLine());

        if (EhFibonacci(numero))
        {
            Console.WriteLine($"O número {numero} pertence à sequência de Fibonacci!");
        }
        else
        {
            Console.WriteLine($"O número {numero} NÃO pertence à sequência de Fibonacci.");
        }
    }

    // Função que verifica se um número pertence à sequência de Fibonacci
    static bool EhFibonacci(int num)
    {
        int a = 0, b = 1, temp;
        
        while (a <= num)
        {
            if (a == num) return true;
            temp = a + b;
            a = b;
            b = temp;
        }

        return false;
    }
}
