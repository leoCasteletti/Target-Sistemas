using System;
using System.Text;

class Program
{
    static void Main()
    {
        // Definir a codificação do console para UTF-8
        Console.OutputEncoding = Encoding.UTF8;

        // Definição dos faturamentos por estado
        var faturamento = new (string Estado, double Valor)[]
        {
            ("SP", 67836.43),
            ("RJ", 36678.66),
            ("MG", 29229.88),
            ("ES", 27165.48),
            ("Outros", 19849.53)
        };

        // Cálculo do faturamento total
        double faturamentoTotal = 0;
        foreach (var estado in faturamento)
        {
            faturamentoTotal += estado.Valor;
        }

        // Exibição dos percentuais
        Console.WriteLine("Percentual de Representação por Estado:");
        foreach (var estado in faturamento)
        {
            double percentual = (estado.Valor / faturamentoTotal) * 100;
            Console.WriteLine($"{estado.Estado}: {percentual:F2}%");
        }
    }
}
