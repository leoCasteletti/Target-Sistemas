using System;
using System.Text;

class Program
{
    static void Main()
    {
        // Define a codificação do console para UTF-8
        Console.OutputEncoding = Encoding.UTF8;

        int INDICE = 13, SOMA = 0, K = 0;

        while (K < INDICE)
        {
            K = K + 1;
            SOMA = SOMA + K;
        }

        Console.WriteLine("O valor da variável SOMA é: " + SOMA); // Resultado: 91
    }
}
